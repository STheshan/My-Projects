/* global bootstrap: false */
(function () {
  'use strict'
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.forEach(function (tooltipTriggerEl) {
    new bootstrap.Tooltip(tooltipTriggerEl)
  })
})()

  document.getElementById('dash_href_db').addEventListener('click', () => {
  document.getElementById('dash_btn_db').classList.add('shadow')
  document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1icon')
  document.getElementById('dash_btn_icn_db').classList.add('dashbtn1iconck')
  document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1text')
  document.getElementById('dash_btn_txt_db').classList.add('dashbtn1textck')

  document.getElementById('dash_btn_btl').classList.remove('shadow')
  document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_itm').classList.remove('shadow')
  document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_emp').classList.remove('shadow')
  document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1textck')
  
});


var data=document.getElementById('header').innerHTML;
if (String(data) == 'Bottles'){
  document.getElementById('dash_btn_btl').classList.add('shadow')
  document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1icon')
  document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1text')
  document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1textck')

  document.getElementById('dash_btn_db').classList.remove('shadow')
  document.getElementById('dash_btn_icn_db').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_db').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_itm').classList.remove('shadow')
  document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_emp').classList.remove('shadow')
  document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_sls').classList.remove('shadow')
  document.getElementById('dash_btn_icn_sls').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_sls').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_sls').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_sls').classList.remove('dashbtn1textck')
}
else if (String(data) == 'Items'){
  document.getElementById('dash_btn_itm').classList.add('shadow')
  document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1icon')
  document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1text')
  document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1textck')

  document.getElementById('dash_btn_db').classList.remove('shadow')
  document.getElementById('dash_btn_icn_db').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_db').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_btl').classList.remove('shadow')
  document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_emp').classList.remove('shadow')
  document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1textck')
  
  document.getElementById('dash_btn_sls').classList.remove('shadow')
  document.getElementById('dash_btn_icn_sls').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_sls').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_sls').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_sls').classList.remove('dashbtn1textck')
}
  else if (String(data) == 'Employees'){
    document.getElementById('dash_btn_emp').classList.add('shadow')
    document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1icon')
    document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1iconck')    
    document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1text')
    document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1textck')
  
    document.getElementById('dash_btn_db').classList.remove('shadow')
    document.getElementById('dash_btn_icn_db').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1iconck')
    document.getElementById('dash_btn_txt_db').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1textck')
  
    document.getElementById('dash_btn_btl').classList.remove('shadow')
    document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1iconck')    
    document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1textck')
  
    document.getElementById('dash_btn_itm').classList.remove('shadow')
    document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1iconck')
    document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1textck')

    document.getElementById('dash_btn_sls').classList.remove('shadow')
    document.getElementById('dash_btn_icn_sls').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_sls').classList.remove('dashbtn1iconck')
    document.getElementById('dash_btn_txt_sls').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_sls').classList.remove('dashbtn1textck')
}
  else if(String(data) == 'Salary'){
    document.getElementById('dash_btn_sls').classList.add('shadow')
    document.getElementById('dash_btn_icn_sls').classList.remove('dashbtn1icon')
    document.getElementById('dash_btn_icn_sls').classList.add('dashbtn1iconck')
    document.getElementById('dash_btn_txt_sls').classList.remove('dashbtn1text')
    document.getElementById('dash_btn_txt_sls').classList.add('dashbtn1textck')

    document.getElementById('dash_btn_db').classList.remove('shadow')
    document.getElementById('dash_btn_icn_db').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1iconck')
    document.getElementById('dash_btn_txt_db').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1textck')

    document.getElementById('dash_btn_btl').classList.remove('shadow')
    document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1iconck')    
    document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1textck')

    document.getElementById('dash_btn_itm').classList.remove('shadow')
    document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1iconck')
    document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1textck')

    document.getElementById('dash_btn_emp').classList.remove('shadow')
    document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1icon')
    document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1iconck')    
    document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1text')
    document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1textck')
}
else {
  document.getElementById('dash_btn_db').classList.add('shadow')
  document.getElementById('dash_btn_icn_db').classList.remove('dashbtn1icon')
  document.getElementById('dash_btn_icn_db').classList.add('dashbtn1iconck')
  document.getElementById('dash_btn_txt_db').classList.remove('dashbtn1text')
  document.getElementById('dash_btn_txt_db').classList.add('dashbtn1textck')

  document.getElementById('dash_btn_btl').classList.remove('shadow')
  document.getElementById('dash_btn_icn_btl').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_btl').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_btl').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_btl').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_itm').classList.remove('shadow')
  document.getElementById('dash_btn_icn_itm').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_itm').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_itm').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_itm').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_emp').classList.remove('shadow')
  document.getElementById('dash_btn_icn_emp').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_emp').classList.remove('dashbtn1iconck')    
  document.getElementById('dash_btn_txt_emp').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_emp').classList.remove('dashbtn1textck')

  document.getElementById('dash_btn_sls').classList.remove('shadow')
  document.getElementById('dash_btn_icn_sls').classList.add('dashbtn1icon')
  document.getElementById('dash_btn_icn_sls').classList.remove('dashbtn1iconck')
  document.getElementById('dash_btn_txt_sls').classList.add('dashbtn1text')
  document.getElementById('dash_btn_txt_sls').classList.remove('dashbtn1textck')
}