from django.db import models
from sympy import false, true
import datetime

from employee.models import Employee

# Create your models here.
class Salary(models.Model):
    emp_id = models.CharField(max_length=250)
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    email = models.CharField(max_length=250)
    contact = models.CharField(max_length=250)
    emirates_id = models.CharField(max_length=250)
    bank = models.CharField(max_length=250)
    iban = models.CharField(max_length=250)
    basic_salary = models.IntegerField()
    additions = models.IntegerField()
    deductions = models.IntegerField()
    net_salary = models.IntegerField()