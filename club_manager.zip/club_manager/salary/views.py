from unittest import result
from django.shortcuts import render
from django.urls import reverse_lazy
from django.db.models import Q
from django.views.generic import CreateView, UpdateView, DeleteView, ListView
import csv
from django.http import HttpResponse
import json
from json import dumps
from django.http import JsonResponse

# Create your views here.
from salary.models import Salary
from employee.models import Employee


class salaryListView(ListView):
    model = Salary
    template_name = "salary/salary-list.html"
    def get_queryset(self):
        query = self.request.GET.get('search')
        try:
            if query:
                stk = []
                object_list = Salary.objects.filter(Q(emp_id = query))
                for object in object_list:
                    id = object.id
                    emp_id = object.emp_id
                    emirates_id = object.emirates_id
                    first_name= object.first_name
                    last_name= object.last_name
                    contact=object.contact
                    net_salary = object.net_salary
                    additions=object.additions
                    deductions= object.deductions
                    email = object.email
                    bank= object.bank
                    iban = object.iban
                    basic_salary = object.basic_salary
                    stk.append({'id':id,'emp_id': emp_id,'emirates_id':emirates_id, 'first_name': first_name, 'last_name': last_name, 'basic_salary':basic_salary, 'additions':additions,'deductions':deductions,'net_salary': net_salary , 'contact':contact, 'email':email, 'bank':bank,'iban':iban , 'basic_salary':basic_salary
                    })
                return stk
            else:
                stk = []
                object_list = Salary.objects.all()
                for object in object_list:
                    id = object.id
                    emp_id = object.emp_id
                    emirates_id = object.emirates_id
                    first_name= object.first_name
                    last_name= object.last_name
                    contact=object.contact
                    net_salary = object.net_salary
                    additions=object.additions
                    deductions= object.deductions
                    email = object.email
                    bank= object.bank
                    iban = object.iban
                    basic_salary = object.basic_salary
                    stk.append({'id':id,'emp_id': emp_id,'emirates_id':emirates_id, 'first_name': first_name, 'last_name': last_name, 'basic_salary':basic_salary, 'additions':additions,'deductions':deductions,'net_salary': net_salary , 'contact':contact, 'email':email, 'bank':bank,'iban':iban , 'basic_salary':basic_salary
                    })
                return stk
        except:
            stk = []
            object_list = Salary.objects.all()
            for object in object_list:
                id = object.id
                emp_id = object.emp_id
                emirates_id = object.emirates_id
                first_name= object.first_name
                last_name= object.last_name
                contact=object.contact
                net_salary = object.net_salary
                additions=object.additions
                deductions= object.deductions
                email = object.email
                bank= object.bank
                iban = object.iban
                basic_salary = object.basic_salary
                stk.append({'id':id,'emp_id': emp_id,'emirates_id':emirates_id, 'first_name': first_name, 'last_name': last_name, 'basic_salary':basic_salary, 'additions':additions,'deductions':deductions,'net_salary': net_salary , 'contact':contact, 'email':email, 'bank':bank,'iban':iban , 'basic_salary':basic_salary
                })
            return stk
        

class salaryCreateView(CreateView):
    model = Salary
    template_name = "salary/salary-form.html"
    success_url = reverse_lazy('salary:salary-list')
    fields = "__all__"
    

class salaryUpdateView(UpdateView):
    model = Salary
    template_name = "salary/salary-update.html"
    success_url = reverse_lazy('salary:salary-list')
    fields = "__all__"


class salaryDeleteView(DeleteView):
    model = Salary
    template_name = ""
    success_url = reverse_lazy('salary:salary-list')

def exportcsv(request):
    model = Salary
    Salary_report = Salary.objects.all()
    response = HttpResponse('text/csv')
    response['Content-Disposition'] = 'attachment; filename=Salaries.csv'
    writer = csv.writer(response)
    writer.writerow(['ID','Emirates ID', 'First Name', 'Last Name', 'Contact','Email' ,'Bank' , 'IBAN', 'Basic Salary','Addiditions', 'Deductions' 'Net Salary'])
    for object in Salary_report:
        id = object.id
        emp_id = object.emp_id
        emirates_id = object.emirates_id
        first_name= object.first_name
        last_name= object.last_name
        contact=object.contact
        net_salary = object.net_salary
        additions=object.additions
        deductions= object.deductions
        email = object.email
        bank= object.bank
        iban = object.iban
        basic_salary=basic_salary
        Salary_report = (emp_id,emirates_id,first_name,last_name,contact,email,bank,iban,basic_salary,additions,deductions,net_salary)
        writer.writerow(Salary_report)
    return response

def send_ids(request):
    # create data dictionary
        stk = []
        object_list = Employee.objects.all()
        for object in object_list:
            id = object.id
            occupation_id = object.occupation_id
            emp_id =  occupation_id +"00" + str(id)
            emirates_id = object.emirates_id
            first_name= object.first_name
            last_name= object.last_name
            contact=object.contact
            email = object.email
            bank= object.bank
            iban = object.iban
            basic_salary = object.basic_salary
            stk.append({'emp_id': emp_id,'emirates_id':emirates_id, 'first_name': first_name, 'last_name': last_name, 'contact':contact, 'email':email, 'bank':bank,'iban':iban , 'basic_salary':basic_salary
            })
        return render(request, 'salary/salary-form.html', {'df_json': stk})

def sav_data(request):
    emp_id = request.POST.get('emp_id')
    first_name = request.POST.get('first_name')
    last_name = request.POST.get('last_name')
    emirates_id = request.POST.get('emirates_id')
    bank = request.POST.get('bank')
    contact = request.POST.get('contact')
    additions = request.POST.get('additions')
    basic_salary = request.POST.get('basic_salary')
    deductions = request.POST.get('deductions')
    net_salary = request.POST.get('net_salary')
    email = request.POST.get('email')
    iban = request.POST.get('iban')
    s = Salary(emp_id = emp_id, emirates_id = emirates_id, first_name = first_name, last_name = last_name, bank=bank, email = email, iban = iban, contact = contact, additions=additions, basic_salary = basic_salary, deductions = deductions, net_salary = net_salary)
    s.save()
    return render(request, 'salary/salary-form.html')