from django.db import models
from sympy import false, true
import datetime


# Create your models here.
class Items(models.Model):
    item_name = models.CharField(max_length=250)
    category = models.CharField(max_length=250)
    category_id = models.CharField(max_length=250)
    quantity = models.IntegerField()
    unit_cost = models.IntegerField()
    purchase_date = models.DateField()