from django.db import models
from sympy import false, true
import datetime

# Create your models here.
class Employee(models.Model):
    emirates_id = models.CharField(max_length=250)
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    email = models.CharField(max_length=250)
    contact = models.CharField(max_length=250)
    occupation = models.CharField(max_length=250)
    occupation_id = models.CharField(max_length=250)    
    bank = models.CharField(max_length=250)
    iban = models.CharField(max_length=250)
    basic_salary = models.IntegerField(default=0000)
    joined_date = models.DateField()