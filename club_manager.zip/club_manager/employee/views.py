from unittest import result
from django.shortcuts import render
from django.urls import reverse_lazy
from django.db.models import Q
from django.views.generic import CreateView, UpdateView, DeleteView, ListView
import xlwt
import csv
from django.http import HttpResponse
from json import dumps

# Create your views here.
from employee.models import Employee


class employeeListView(ListView):
    model = Employee
    template_name = "employee/employee-list.html"
    def get_queryset(self):
        query = self.request.GET.get('search')
        if query:
            stk = []
            query = query[3:]
            object_list = Employee.objects.filter(Q(id = int(query)))
            for object in object_list:
                id = object.id
                emirates_id = object.emirates_id
                first_name= object.first_name
                last_name= object.last_name
                email = object.email
                contact = object.contact
                occupation = object.occupation
                joined_date = object.joined_date
                basic_salary = object.basic_salary
                occupation_id = object.occupation_id
                emp_id =  occupation_id +"00" + str(id)
                stk.append({'id':id,'emp_id': emp_id, 'emirates_id': emirates_id,'first_name': first_name, 'last_name': last_name, 'email': email, 'contact': contact, 'occupation':occupation, 'basic_salary':basic_salary,'joined_date':joined_date
                })
            return stk
        else:
            stk = []
            object_list = Employee.objects.all()
            for object in object_list:
                id = object.id
                emirates_id = object.emirates_id
                first_name= object.first_name
                last_name= object.last_name
                email = object.email
                contact = object.contact
                occupation = object.occupation
                joined_date = object.joined_date
                basic_salary = object.basic_salary
                occupation_id = object.occupation_id
                emp_id =  occupation_id +"00" + str(id)
                stk.append({'id':id,'emp_id': emp_id, 'emirates_id': emirates_id,'first_name': first_name, 'last_name': last_name, 'email': email, 'contact': contact, 'occupation':occupation, 'basic_salary':basic_salary,'joined_date':joined_date
                })
            return stk
        

class employeeCreateView(CreateView):
    model = Employee
    template_name = "employee/employee-form.html"
    success_url = reverse_lazy('employee:employee-list')
    fields = "__all__"

class employeeUpdateView(UpdateView):
    model = Employee
    template_name = "employee/employee-form.html"
    success_url = reverse_lazy('employee:employee-list')
    fields = "__all__"


class employeeDeleteView(DeleteView):
    model = Employee
    template_name = ""
    success_url = reverse_lazy('employee:employee-list')

def exportcsv(request):
    model = Employee
    Employee_report = Employee.objects.all()
    response = HttpResponse('text/csv')
    response['Content-Disposition'] = 'attachment; filename=Employees.csv'
    writer = csv.writer(response)
    writer.writerow(['ID', 'Emirates ID','First Name', 'Last Name', 'Email', 'Contact', 'Occupation','Basic Salary','Bank', 'Iban','Joined Date'])
    for object in Employee_report:
        id = object.id
        emirates_id = object.emirates_id
        first_name= object.first_name
        last_name= object.last_name
        email = object.email
        contact = object.contact
        occupation = object.occupation
        joined_date = object.joined_date
        occupation_id = object.occupation_id
        basic_salary = object.basic_salary
        bank = object.bank
        iban = object.iban
        emp_id =  occupation_id +"00" + str(id)
        Employee_report = (emp_id,emirates_id,first_name,last_name,email,contact,occupation,basic_salary,bank,iban,joined_date)
        writer.writerow(Employee_report)
    return response