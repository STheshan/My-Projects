from django.db import models

# Create your models here.
from django.db import models
from sympy import false, true
import datetime

# Create your models here.
class Bottles(models.Model):
    bottle_name = models.CharField(max_length=250)
    liquor_type_id = models.CharField(max_length=250)
    liquor_type = models.CharField(max_length=250)
    size = models.CharField(max_length=250)
    quantity = models.IntegerField()
    unit_cost = models.IntegerField()
    unit_price = models.IntegerField()
    purchase_date = models.DateField()
