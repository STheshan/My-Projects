from unittest import result
from django.shortcuts import render
from django.urls import reverse_lazy
from django.db.models import Q
from django.views.generic import CreateView, UpdateView, DeleteView, ListView
import xlwt
import csv
from django.http import HttpResponse
from json import dumps

# Create your views here.
from bottles.models import Bottles


class bottlesListView(ListView):
    model = Bottles
    template_name = "bottles/bottles-list.html"
    def get_queryset(self):
        query = self.request.GET.get('search')
        if query:
            stk = []
            query = query[3:]
            object_list = Bottles.objects.filter(Q(id = int(query)))
            for object in object_list:
                id = object.id
                bottle_name= object.bottle_name
                liquor_type= object.liquor_type
                quantity = object.quantity
                unit_cost = object.unit_cost
                unit_price = object.unit_price
                size = object.size
                liquor_type_id = object.liquor_type_id
                bottle_id = liquor_type_id + "00" + str(id)
                stk.append({'id':id,'bottle_id': bottle_id,'bottle_name': bottle_name, 'liquor_type': liquor_type, 'size': size, 'quantity': quantity,'unit_cost': unit_cost, 'unit_price': unit_price
                })
            return stk
        else:
            stk = []
            object_list = Bottles.objects.all()
            for object in object_list:
                id = object.id
                bottle_name= object.bottle_name
                liquor_type= object.liquor_type
                quantity = object.quantity
                unit_cost = object.unit_cost
                unit_price = object.unit_price
                size = object.size
                liquor_type_id = object.liquor_type_id
                bottle_id = liquor_type_id + "00" + str(id)
                stk.append({'id':id,'bottle_id': bottle_id,'bottle_name': bottle_name, 'liquor_type': liquor_type, 'size': size, 'quantity': quantity,'unit_cost': unit_cost, 'unit_price': unit_price
                })
            return stk
        

class bottlesCreateView(CreateView):
    model = Bottles
    template_name = "bottles/bottles-form.html"
    success_url = reverse_lazy('bottles:bottles-list')
    fields = "__all__"

class bottlesUpdateView(UpdateView):
    model = Bottles
    template_name = "bottles/bottles-form.html"
    success_url = reverse_lazy('bottles:bottles-list')
    fields = "__all__"


class bottlesDeleteView(DeleteView):
    model = Bottles
    template_name = ""
    success_url = reverse_lazy('bottles:bottles-list')

def exportcsv(request):
    model = Bottles
    Bottles_report = Bottles.objects.all()
    response = HttpResponse('text/csv')
    response['Content-Disposition'] = 'attachment; filename=Bottles.csv'
    writer = csv.writer(response)
    writer.writerow(['ID', 'Bottle Name', 'Liquor Type', 'Size', 'Quantity','Unit Cost', 'Unit Price'])
    for object in Bottles_report:
        id = object.id
        bottle_name= object.bottle_name
        liquor_type= object.liquor_type
        quantity = object.quantity
        unit_cost = object.unit_cost
        unit_price = object.unit_price
        size = object.size
        liquor_type_id = object.liquor_type_id
        bottle_id = liquor_type_id + "00" + str(id)
        Bottles_report = (bottle_id,bottle_name,liquor_type,size,quantity,unit_cost,unit_price)
        writer.writerow(Bottles_report)
    return response