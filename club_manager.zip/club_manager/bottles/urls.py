from django.urls import path
from bottles.views import bottlesListView, bottlesCreateView, bottlesUpdateView, bottlesDeleteView , exportcsv 

app_name = 'bottles'
urlpatterns = [
    path('', bottlesListView.as_view(), name='bottles-list'),
    path('create', bottlesCreateView.as_view(), name='bottles-create'),
    path('update/<int:pk>', bottlesUpdateView.as_view(), name='bottles-update'),
    path('delete/<int:pk>', bottlesDeleteView.as_view(), name='bottles-delete'),
    path('search', bottlesListView.as_view(), name='bottles-search'),
    path('exportcsv', exportcsv, name='bottles-report'),
]