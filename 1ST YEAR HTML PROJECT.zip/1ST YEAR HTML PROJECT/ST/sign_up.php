<?php	include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="css/sign_up.css">

	<div class="space_area"></div>
	<div class="signup_area">
		<div class="signup_area_right"> <!-- signup_area_right -->

		<form action="includes/signup_recod.php" method="post" class="sign_up clearfix">
		<ul>
		<li><h4>Name:</h4><input type="text" name="name" id="name"></li><br>
		<li><h4>Email:</h4><input type="email" name="email" id="email"></li><br>
		<li><h4>Password:</h4><input type="password" name="password" id="password"></li><br>
		<li><h4>Birthday:</h4><input type="date" name="birthday" id="birthday"></li><br>
		<li><table><tr>
			<td><h4>Male:</h4></td><td><input type="radio" name="gender" value="male"></td></tr>
			<tr><td><h4>Female:</h4></td><td><input type="radio" name="gender" value="female"></td></tr>
			</table></li>
		<li><button type="submit" value="submit" name="register">register</button></li>
		</ul>
		</form>
		</div><!-- signup_area_right -->

		<div class="signup_area_left"><!-- signup_area_left -->
			<div class="inside_left"><!-- inside_left -->
				<h2>Sign up on Hello Jobs</h2>
			</div><!-- inside_left -->
		</div><!-- signup_area_left -->
	</div><!-- signup_area_right -->


</body>
</html>
<?php mysqli_close($connect); ?>