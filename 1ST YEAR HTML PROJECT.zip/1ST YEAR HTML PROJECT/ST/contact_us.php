<?php	include('header.php');?>
<link rel="stylesheet" type="text/css" href="css/contact_us.css">

	<div class="space_area"></div>
	<div class="contact_us_area">
		<div class="contact_us_area_right">
		<form action="contact_us.php" class="contact_us clearfix">
		<ul>
		<li><h4>Name:</h4><input type="text" name="name" ></li><br>
		<li><h4>Email:</h4><input type="email" name="email" ></li><br>
		<li><h4>Message:</h4><textarea name="Message"></textarea></li><br>
		<li><button type="submit">Submit</button>
			<button type="Reset">Reset</button></li>
		</ul>
		</form>
		</div>
		<div class="contact_us_area_left">
			<div class="inside_left">
				<h2>Contact Us!</h2>
			</div>
		</div>
	</div>
</body>
</html>