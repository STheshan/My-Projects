<!DOCTYPE html>
<html>
<head>
	<title>Hello Jobs</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
	<div class="wrapper"><!--wrapper-->
		<div class="top-bar clearfix"><!--top bar-->
			
			<div class="top-bar-links"><!--top bar links -->
				<ul>
					<li><a href="sign_up.php">Sign up</a></li>
					<li><a href="login.php">log in</a></li>
					<li><a href="post_ad.php">Post ad!</a></li>
				</ul>
			</div><!--top-bar-links-->
			
			<div class="site-search"><!--site search -->
				<form method ="get" action ="home.php">
					<input type="search" name="search box">
					<button type="submit"></button>
				</form>
			</div><!--site search -->
		</div><!--top-bar-->
	</div><!--wrapper-->

	<header>
		<div class="logo">
			<h1>Hello Jobs</h1>
			<p>Find Your Future Target</p>
			
		</div><!--logo-->
		<div class="socialmedia">
			<ul>
			<li><a href="#"><i class="fa fa-linkedin fa-fw" aria-hidden="true"></i></a></li>
			<li><a href="#"><i class="fa fa-twitter fa-fw" aria-hidden="true"></i></a></li>
			<li><a href="#"><i class="fa fa-pinterest fa-fw" aria-hidden="true"></i></a></li>
			<li><a href="#"><i class="fa fa-google-plus fa-fw" aria-hidden="true"></i></a></li>
			<li><a href="#"><i class="fa fa-rss fa-fw" aria-hidden="true"></i></a></li>
			</ul>
		</div><!--socialmedia-->
	</header>
	<nav class = "clearfix">
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="about_us.php">About US</a></li>
			<li><a href="Contact_us.php">Contact us</a></li>
		</ul>
	</nav>