<?php	include('header.php'); ?>
<link rel="stylesheet" type="text/css" href="css/login.css">

	<div class="space_area"></div>
	<div class="login_area">
		<div class="login_area_right">
		<form action="login.php" method="post" class="login clearfix">
		<ul>
		<li><h4>Username:</h4><input type="text" name="name" id="name"></li><br>
		<li><h4>Password:</h4><input type="password" name="password" id="password"></li><br>
		<li><button type="submit" value="insert" name="login">LOGIN</button></li>
		</ul>
		</form>
		</div>
		<div class="login_area_left">
			<div class="inside_left">
				<h2>Login into the Hello Jobs</h2>
			</div>
		</div>
	</div>

</body>
</html>