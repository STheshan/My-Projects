
<?php 

  	$con = mysqli_connect("localhost","root","","signup");

    $email = $_POST['email'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $birthday = $_POST['birthday'];
    $gender = $_POST['gender'];

  	$insert = "INSERT INTO signup_recod(email,name,password,birthday,gender)VALUES ('$email','$name','$password','$birthday','$gender')";
  	 if (!mysqli_query($con,$insert)) 
  	 {
  	 	die('ERROR:'.mysqli_error($con));
  	 }
  	 else
  	 {
      echo "<script type='text/javascript'>alert('You have successfully sign up.thank you!')</script>";
      include('../home.php');
  	 }

  	mysqli_close($con);
   ?> 