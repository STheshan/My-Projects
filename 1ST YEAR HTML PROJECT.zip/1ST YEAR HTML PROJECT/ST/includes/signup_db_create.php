<?php 

	$con = mysqli_connect("localhost","root","");

	if(mysqli_connect_errno())
	{
		echo "failed".mysqli_connect_errno();
	}
	else
	{
		echo "done";
		echo "<br>";
	}
	
	$create_db="CREATE DATABASE signup";

	if(mysqli_query($con,$create_db))
	{
		echo "success";
	}
	else
	{
		echo "faild";
	}
	mysqli_close($con);
	
 ?>
 <?php 

 	$con = mysqli_connect("localhost","root","","signup");

 	$creat_tbl = "CREATE TABLE signup_recod(email varchar(50) PRIMARY KEY,name varchar(50),password varchar(50),birthday varchar(50),gender varchar(10))";
 	if (mysqli_query($con,$creat_tbl)) 
 	{
 		echo "table done";
 		echo "<br>";
 	}
 	else
 	{
 		echo "error table";
 	}


  ?>
